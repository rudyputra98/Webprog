<?php
	
	session_start();
	include 'connect.php';

	$kode = $_GET['kode'];
	$today = date("Y-m-d");
	$Userid = $_SESSION['id'];

	$timestamp = date("H:i:s", strtotime('+6 hours'));

	$query = "INSERT INTO trheader(Trid, Userid, Trdate, Trtime, Status) VALUES (NULL,'$Userid','$today','$timestamp','Pending')";

	$result = mysqli_query($conn,$query);
	
	if(!$result){
		header("Location: ../order.php?error=Error! Please try again");
	}
	else{
		$query3 = "SELECT * FROM trheader Order By Trid DESC LIMIT 1";
		$result3 = mysqli_query($conn,$query3);	
		$row = mysqli_fetch_array($result3);
		$Trid = $row["Trid"];
		$query2 = "INSERT INTO trdetail(Trid, KodePaket) VALUES ('$Trid','$kode')";
		$result2 = mysqli_query($conn,$query2);
		if(!$result2){
			header("Location: ../order.php?error=Error! Please try again");		
		}else{
			header("Location: ../order.php?error=Order Successfully!");
		}
	}

	
	mysqli_close($conn);
?>