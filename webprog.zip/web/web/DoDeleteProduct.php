<?php
	
	session_start();
	include 'connect.php';

	$id = $_SESSION['id'];
	$KodePaket = $_GET['kode'];

	$query = "DELETE FROM product WHERE KodePaket = '$KodePaket'";
	$result = mysqli_query($conn,$query);

	header("Location: ../log_okadmin.php");
	
	mysqli_close($conn);

?>