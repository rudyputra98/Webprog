<?php
	
	session_start();
	include 'connect.php';

	$name = $_POST['nama'];
	$rincian = $_POST['rincian'];
	$harga1 = $_POST['harga'];
	$KodePaket = "";


	$query2 = "SELECT * FROM product WHERE NamaPaket='$name'";
	$result2 = mysqli_query($conn,$query2);
	$row1 = mysqli_fetch_array($result2);

	$query3 = "SELECT substring(KodePaket,-1,1) AS KodePaketLastDigit,substring(KodePaket,-2,1) AS KodePaketSecondLastDigit,substring(KodePaket,-3,1) AS KodePaketThirdLastDigit FROM product ORDER BY KodePaket DESC LIMIT 1";
	$result3 = mysqli_query($conn,$query3);
	$row = mysqli_fetch_array($result3); 
	
	$KodePaketLastDigit = (int)$row["KodePaketLastDigit"];
	$KodePaketSecondLastDigit = (int)$row["KodePaketSecondLastDigit"];
	$KodePaketThirdLastDigit = (int)$row["KodePaketThirdLastDigit"];	


	if($row1!=null){
		header("Location: ../log_okadmin.php?error=This Package Name has been registered!");
	} 
	else{
	$r = array();
	$harga1 = strrev($harga1);
	$t = floor((int)strlen($harga1)/3);
	$u = 0;
    for($i=0; $i<(strlen($harga1)+$t); $i++){
         
         if($i!=(strlen($harga1)+$t)){
	         
	         if(($i+1)%4==0){
	         	$r[$i] = ".";
	         	$u++;
	         }else{
	         	$r[$i] = $harga1[$i-$u];
	         }
         }else{
         	$r[$i] = "";
         }
    }

	$harga1 = "Rp ".strrev(implode("", $r)).",-";    

		if($KodePaketLastDigit==9){
			$KodePaketLastDigit = 0;
			$KodePaketSecondLastDigit = $KodePaketSecondLastDigit + 1;	
		}
		else{
			$KodePaketLastDigit = $KodePaketLastDigit + 1;	
		}
		if($KodePaketSecondLastDigit==9){
			$KodePaketSecondLastDigit = 0;
			$KodePaketThirdLastDigit = $KodePaketThirdLastDigit + 1;
		}
		
		$KodePaket = "PK".$KodePaketThirdLastDigit.$KodePaketSecondLastDigit.$KodePaketLastDigit;
		$query = "INSERT INTO product(KodePaket, NamaPaket, Rincian, Harga) VALUES ('$KodePaket','$name','$rincian','$harga1')";
		$result = mysqli_query($conn,$query);
	}

	header("Location: ../log_okadmin.php?error=Add Product successfully!");
	mysqli_close($conn);

?>