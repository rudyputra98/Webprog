<?php
	
	session_start();
	include 'connect.php';

	$name = $_POST['name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$pass = $_POST['password'];
	$address = $_POST['address'];

	$query2 = "SELECT * FROM account WHERE email='$email'";
	$result2 = mysqli_query($conn,$query2);

	$row = mysqli_fetch_array($result2);

	if($row["email"]==$email){
		 header("Location: index.php?error=This email has been registered!");
	} 
	else{
		$query = "INSERT INTO account(Userid, name, email, phone, password, address) VALUES (NULL,'$name','$email','$phone','$pass','$address')";
		$result = mysqli_query($conn,$query);
		if(!$result){
			header("Location: index.php?error=Error! Please try again");
		}
		else{
			header("Location: index.php?error=Register successfully!");
		}
	}

	mysqli_close($conn);

?>