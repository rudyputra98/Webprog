<?php
	
	session_start();
	include 'connect.php';

	$Trid = $_GET['Trkode'];

	$query = "DELETE FROM trheader WHERE Trid = '$Trid'";
	$result = mysqli_query($conn,$query);

	header("Location: ../order.php?error=Revoke success!");
	mysqli_close($conn);
?>