<?php
	session_start();
	include 'connect.php';

	$email = $_POST['email'];
	$pass = $_POST['password'];
	$check = $_POST['checkbox'];
	
	$query = "SELECT * FROM account WHERE email='$email' AND password='$pass'";
	$result = mysqli_query($conn,$query);

	if(!$row = mysqli_fetch_assoc($result)){
		header("Location: index.php?error=Your account is invalid");
	}else{
		$_SESSION['name'] = $row['name'];
		$_SESSION['id'] = $row['Userid'];
		$_SESSION['role'] = $row['role'];
		
		if(strcmp($_SESSION['role'],"member")==0){
			header("Location: ../log_ok.php");
		}else{
			header("Location: ../log_okadmin.php");
		}
	}

	if(!empty($check)) {
		setcookie ("member_login",$email,time()+ (60 * 60));
		setcookie ("member_password",$pass,time()+ (60 * 60));
	}

	mysqli_close($conn);

?>