<?php
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
<title>Forgot Password</title>
<!-- for-mobile-apps -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta name="keywords" content="Account Login Widget Responsive, Login form web template, Sign up Web Templates, Flat Web Templates, Login signup Responsive web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<!-- //for-mobile-apps -->
<link href='//fonts.googleapis.com/css?family=Open+Sans:400,600,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,700,900,300' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<script src="js/jquery-1.11.1.min.js"></script> 
<!-- //js -->
<!-- chart -->
<script src="js/Chart.js"></script>
<!-- //chart -->
<script src="js/easyResponsiveTabs.js" type="text/javascript"></script>
	<script type="text/javascript">
		$(document).ready(function () {
			$('#horizontalTab').easyResponsiveTabs({
				type: 'default', //Types: default, vertical, accordion           
				width: 'auto', //auto or any width like 600px
				fit: true   // 100% fit in a container
			});
		});
	   </script>
</head>
<body>
<div class="content">
	<div style="text-align: center;">
		<?php 
        	if(strcmp($_SESSION['role'],"member")==0){
        ?>
			<a href="../log_ok.php"><img src="images/logo3.png" style="max-width: 200px;"></a>
		<?php
			}else{ 
		?>
			<a href="../log_okadmin.php"><img src="images/logo3.png" style="max-width: 200px;"></a>
		<?php	
			}
		?>
	</div>
	<h1>Change Password</h1>
		<div class="main">
			<div class="profile-left wthree">
				<div class="sap_tabs">
				<div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">
					<ul class="resp-tabs-list">
						<li class="resp-tab-item" aria-controls="tab_item-0" role="tab" style="background-color: #0d4061"></li>
						<div class="clear"> </div>
					</ul>			
					<div class="resp-tabs-container">
						<div class="tab-1 resp-tab-content" aria-labelledby="tab_item-0">
						<div class="got">
						</div>
							<div class="login-top">
								<form action="DoChangePass.php" method="POST">
									<input type="password" name="opassword" class="password" placeholder="Old Password" required>
									<input type="password" name="password" class="password" placeholder="New Password" required>
									<input type="password" name="cpassword" class="password" placeholder="Confirm Password" required>	
									<input type="checkbox" name="checkbox" id="brand" value="">
									<div class="login-bottom">
									<ul>
										<li>
												<input type="submit" value="Change Password">
										</li>
									<ul>
									<div class="clear" style="text-align: center;">
										<br>
										<?php 
											if(isset($_GET['error'])){
												echo $_GET['error']; 
												}
										?>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>	
				</div>
				<div class="clear"> </div>
			</div>
			<div class="clear"> </div>
	</div>	
	<p class="footer">&copy; 2016 Account Login Widget. All Rights Reserved | Design by <a href="http://w3layouts.com/"> W3layouts</a></p>
</div>
<script type="text/javascript" src="js/validation.js"></script>
</body>
</html>
