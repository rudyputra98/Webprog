<?php
	
	session_start();
	include 'connect.php';

	$opass = $_POST['opassword'];
	$pass = $_POST['password'];
	$cpass = $_POST['cpassword'];
	$id = $_SESSION['id'];


	$query = "SELECT password FROM account WHERE Userid='$id'";
	$result = mysqli_query($conn,$query);
	$row = mysqli_fetch_assoc($result);

	if($opass!=$row["password"]){
		header("Location: changepassword.php?error=Wrong Password!");
	}
	else if($pass != $cpass){
		header("Location: changepassword.php?error=Password didn't match!");
	}else{
		$query2 = "UPDATE account SET password = '$pass' WHERE Userid='$id'";
		$result = mysqli_query($conn,$query2);
		if($result){
			header("Location: changepassword.php?error=Successfully change password!");
		}
	}

	mysqli_close($conn);

?>