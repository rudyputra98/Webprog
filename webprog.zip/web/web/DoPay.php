<?php  

	session_start();
	include 'connect.php';

	$kode = $_GET['Trkode'];
	$status = "Approved";

	$query = "UPDATE trheader SET Status = '$status' WHERE Trid = '$kode'";
	$result = mysqli_query($conn,$query);

	if(!$result){
		header("Location: ../order.php?error=Error! Please try again");
	}
	else{
		header("Location: ../order.php?error=Transaction Completed!");
	}

	
	mysqli_close($conn);

?>