<?php
	
	session_start();
	include 'connect.php';

	$name = $_POST['nama'];
	$rincian = $_POST['rincian'];
	$harga1 = $_POST['harga'];
	$KodePaket = $_POST['KodePaket'];


	$r = array();
	$harga1 = strrev($harga1);
	$t = floor((int)strlen($harga1)/3);
	$u = 0;
    for($i=0; $i<(strlen($harga1)+$t); $i++){
         
         if($i!=(strlen($harga1)+$t)){
	         
	         if(($i+1)%4==0){
	         	$r[$i] = ".";
	         	$u++;
	         }else{
	         	$r[$i] = $harga1[$i-$u];
	         }
         }else{
         	$r[$i] = "";
         }
    }

	$harga1 = "Rp ".strrev(implode("", $r)).",-";    

	$query = "UPDATE product SET NamaPaket = '$name', Rincian = '$rincian', Harga = '$harga1' WHERE KodePaket = '$KodePaket'";
	$result = mysqli_query($conn,$query);

	header("Location: ../log_okadmin.php?error=Product Updated!");
	mysqli_close($conn);

?>