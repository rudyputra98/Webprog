<?php
	
	session_start();
	include 'connect.php';

	$email = $_POST['email'];
	$pass = $_POST['password'];
	$cpass = $_POST['cpassword'];

	$query = "SELECT * FROM account WHERE email='$email'";
	$result = mysqli_query($conn,$query);

	if(!$row = mysqli_fetch_assoc($result)){
		header("Location: forgotpass.php?error=Account doesn't exist!");
	}
	else if($pass != $cpass){
		header("Location: forgotpass.php?error=Password didn't match!");
	}else{
		$query2 = "UPDATE account SET password = '$pass' WHERE email = '$email'";
		$result = mysqli_query($conn,$query2);
		if($result){
			header("Location: forgotpass.php?error=Password Changed Successfully!");	
		}
	}

	mysqli_close($conn);

?>