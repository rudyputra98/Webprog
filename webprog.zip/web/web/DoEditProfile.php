<?php
	
	session_start();
	include 'connect.php';

	$name = $_POST['name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$address = $_POST['address'];
	$id = $_SESSION['id'];
	$foto = $_POST['foto'];

	$query = "UPDATE account SET name = '$name',email = '$email',phone = '$phone',address = '$address',foto = '$foto' WHERE Userid='$id'";
	$result = mysqli_query($conn,$query);
	if($result){
		header("Location: ../profile.php?error=Profile updated!");
	}
	

	mysqli_close($conn);

?>