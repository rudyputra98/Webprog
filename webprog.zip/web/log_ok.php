<?php
	session_start();
	include 'web/connect.php';
?>

<!DOCTYPE HTML>
<html>
<head>
<title>PeriJasa - Penyakit Rumah, Kami Dokternya</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Concerted Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href='//fonts.googleapis.com/css?family=Viga' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,700,300' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel='stylesheet' type='text/css' />	
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
       <script type="text/javascript" src="js/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
		<script type="text/javascript">
		$(document).ready(function() {
				
		$().UItoTop({ easingType: 'easeOutQuart' });
});
</script>
 <script src="js/jquery.chocolat.js"></script>
		<link rel="stylesheet" href="css/chocolat.css" type="text/css" media="all" />
		<!--light-box-files -->
		<script type="text/javascript">
		$(function() {
			$('#example1 a').Chocolat();
		});
		</script>
		<script type="text/javascript">
		$(function() {
			$('#portfolio a').Chocolat();
		});
		</script>
		<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script src="js/my.js"></script>
<script>
 new WOW().init();
</script>
<!-- //animation-effect -->
<style>
.dropbtn {
    background-color: transparent;
    color: white;
    padding: 4px;
    font-size: 17px;
    border: none;
    cursor: pointer;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    overflow: auto;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown a:hover {background-color: #f1f1f1}

.show {display:block;}
</style>


</head>
<body>
<!-- banner -->
<div class="banner w3l-1">
 <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <h1><a class="navbar-brand" href="home.php"><img src="images/logo3.png" style="width: 140px;height: 40px;"></a></h1>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="#home" class="scroll">Home</a></li>
            <li><a href="#services" class="scroll">Services</a></li>
			<li><a href="#pricing" class="scroll">Pricing</a></li>
			<li><a href="#about" class="scroll">About</a></li>
			<li><a href="#portfolio" class="scroll">Projects</a></li>
            <li><a href="order.php">Order</a></li>
            <li><a href="#contact" class="scroll">Contact</a></li>
            <li>
            	<div class="dropdown" style="margin-top: 9px;">
				<button onclick="myFunction()" class="dropbtn">
            	Hi, 
            	<?php
            		if(isset($_SESSION['name'])){
            			echo $_SESSION['name'];
            		}
            	?></button>
				  <div id="myDropdown" class="dropdown-content">
				    <a href="profile.php">Profile</a>
				    <a href="web/changepassword.php?">Change Password</a>
				  </div>
				</div>
            </h3></li>
            <li><a href="web/DoLogout.php">Log Out</a></li>
          </ul>
        <div class="clearfix"></div>
        </div>
      </div>
    </nav>
	<div class="container">
		<div class="header w3ls-2">
			<div class="logo">
				
			</div>
			
			<div class="clearfix"></div>
		</div>
			<section class="slider">
							<div class="flexslider">
								<ul class="slides">
									<li>
										<div class="banner-info">
											<h3 style="color: orange;"> Rumah selalu berantakan ?</h3>
											<p style="color : orange;">Kami menyadari kebutuhan keluarga rumah tangga di Indonesia akan jasa bersih-bersih rumah yang profesional, praktis, dan terjangkau. Rumah kesayangan Anda juga perlu untuk "dimanjakan" dengan perawatan yang tepat.</p>
										</div>
									</li>
									<li>
										<div class="banner-info">
											<h3 style="color: orange;"> Alat-alat di rumah sering rusak ? </h3>
											<p style="color: orange;">Kami juga menyadari kebutuhan keluarga rumah tangga di Indonesia akan jasa perawatan dan perbaikan alat-alat di rumah Anda. Teknisi ahli kami dapat membuat alat-alat di rumah Anda kembali seperti baru lagi.</p>
										</div>
									</li>
									<li>
										<div class="banner-info">
											<h3 style="color: orange;"> Kebun di rumah Anda tidak karuan ? </h3>
											<p style="color: orange;">Di saat Anda tidak dapat mengurus kebun yang dulu Anda sayangi, kami menyediakan jasa untuk memberikan kebun Anda perhatian lebih, membuat kebun Anda menjadi lebih indah dari sebelumnya.</p>
										</div>
									</li>
									<li>
										<div class="banner-info">
											<h3 style="color: orange;"> Layanan jasa langganan Anda tidak praktis ? </h3>
											<p style="color: orange;">Kami tidak hanya menyediakan tenaga yang ahli di bidangnya masing-masing, tetapi juga package-package yang memastikan pengalaman penggunaan jasa sepraktis mungkin.</p>
										</div>
									</li>										
								</ul>
							</div>
						</section>
							<script>window.jQuery || document.write('<script src="js/libs/jquery-1.7.min.js">\x3C/script>')</script>
												<!--FlexSlider-->
									<script defer src="js/jquery.flexslider.js"></script>
									<script type="text/javascript">
											$(function(){
												
												});
											$(window).load(function(){
											$('.flexslider').flexslider({
												animation: "slide",
												start: function(slider){
												$('body').removeClass('loading');
													}
													});
												});
									</script>
	</div>
</div>
<!-- /banner -->

<!-- services -->
<div class="container">
		<div class="services" id="services">
			<div class="ser-top wthree-3 wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
				<h3>Our Services </h3>
				<p>Berikut adalah layanan jasa rumah tangga yang kami tawarkan</p>
			</div>
				<div class="col-md-4 ser-left wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
					<img src="images/cleaning.png" aria-hidden="true" style="width:40px; height:40px;">
					<h4>House Cleaning</h4>
					<p>Jasa bersih-bersih rumah mulai dari lantai, toilet, bahkan pemolesan keramik/marmer</p>
				</div>
				<div class="col-md-4 ser-left wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
					<!--<span class="glyphicon glyphicon-globe" aria-hidden="true"></span>-->
					<img src="images/bug.png" aria-hidden="true" style="width:40px; height:40px;">
					<h4>Pest Exterminator</h4>
					<p>Terganggu dengan serangga atau hama di rumah Anda? Kami dapat membantu Anda</p>
				</div>
				<div class="col-md-4 ser-left wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
					<!--<span class="glyphicon glyphicon-screenshot" aria-hidden="true"></span>-->
					<img src="images/machine.png" aria-hidden="true" style="width:40px; height:40px;">
					<h4>Maintenance Household Appliances</h4>
					<p>Agar peralatan di rumah Anda awet, dibutuhkan perawatan secara berkala</p>
				</div>
			
				
				<div class="col-md-4 ser-left wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
					<!--<span class="glyphicon glyphicon-heart-empty" aria-hidden="true"></span>-->
					<img src="images/flower.png" aria-hidden="true" style="width:40px; height:40px;">
					<h4>Gardener</h4>
					<p>Mengurus halaman dan tanaman kesayangan Anda dibutuhkan tenaga professional</p>
				</div>
				<div class="col-md-4 ser-left wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
					<!--<span class="glyphicon glyphicon-edit" aria-hidden="true"></span>-->
					<img src="images/shirt.png" aria-hidden="true" style="width:40px; height:40px;">
					<h4>Laundry Services</h4>
					<p>Kami siap membantu Anda dalam hal mencuci, mengeringkan, dan melipat pakaian karena dibutuhkan pengetahuan khusus agar pakaian Anda tidak kusut atau tidak pudar</p>
				</div>
				<div class="col-md-4 ser-left wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
					<!--<span class="glyphicon glyphicon-phone" aria-hidden="true"></span>-->
					<img src="images/repair.png" aria-hidden="true" style="width:40px; height:40px;">
					<h4>Repair Service</h4>
					<p>Selain menyediakan jasa perawatan untuk peralatan rumah Anda,kami juga menyediakan jasa perbaikan untuk itu</p>
				</div>
					<div class="clearfix"></div>
				
		</div>
	</div>
<!-- /services -->

<!-- pricing -->
<div class="container">
	<div class="pri-cing agileits" id="pricing">
		<div class="prc-top">
			<h3>Simple Pricing </h3>
			<p>Berikut adalah paket-paket pelayanan jasa yang kami dapat tawarkan ke Anda</p>
		</div>
		<div class="pricing-table wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s" style="background-color: gray; text-align: center; font-family: Helvetica;">
			<?php
				$query = "SELECT * FROM product";
				$result = mysqli_query($conn,$query);
				while($row = mysqli_fetch_array($result)) { 

			?>
			<div class="price-top">
				<h1> <?php printf("%s\n",$row["NamaPaket"]) ?> </h1><br>
			</div>
			<div class="price-bottom">
				<b><?php printf("%s\n",$row["Rincian"]) ?> </b><br>
				<h2><?php printf("%s\n",$row["Harga"]) ?> </h2><br>
				<a href="web/DoOrder.php?kode=<?php echo $row["KodePaket"] ?>" class="button but3">Get Started</a>
			</div>
			<br>
				<?php } ?>
		</div>	
	</div>
</div>
<!-- /pricing -->
<!-- ready-->	
	<div class="ready w3" id="about">
		<div class="container wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s" ">
			<h4 style="color:orange;">Apa itu PeriJasa ?</h4><br>
			<h4 style="color:orange;">PeriJasa adalah website yang menyediakan paket pelayanan jasa yang bergerak di bidang perawatan rumah, baik dari kebersihan, hingga perawatan alat-alat rumah tangga. </h4>
		</div>
	</div>	
<!-- /ready -->	
<!-- projects -->
<div class="container wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
		<div class="portfolio" id="portfolio">
			<div class="proj-top w3agile">
				<h3>Gallery</h3>
			</div>
			<div class="gallery-bottom">
					<div class="col-md-4 gallery-left">
						<a data-toggle="modal" data-target=".bs-example-modal-md" href="images/9.jpg" class="b-link-stripe b-animate-go  thickbox" title="Rose">
							<img class="img-responsive lot" src="images/9.jpg" alt="" style="width:620px; height:170px;">
							   <div class="b-wrapper">
									<div class="b-animate b-from-left b-delay03 ">
										<i class="plus second"></i>
									</div>
							   </div>
						</a>
					</div>
					<div class="col-md-4 gallery-left">
						<a data-toggle="modal" data-target=".bs-example-modal-md" href="images/10.jpg" class="b-link-stripe b-animate-go  thickbox" title="Rose">
							<img class="img-responsive lot" src="images/10.jpg" alt="">
							   <div class="b-wrapper">
									<div class="b-animate b-from-left b-delay03 ">
										<i class="plus second"></i>
									</div>
							   </div>
						</a>
					</div>
					<div class="col-md-4 gallery-left">
						<a data-toggle="modal" data-target=".bs-example-modal-md" href="images/11.png" class="b-link-stripe b-animate-go  thickbox" title="Rose">
							<img class="img-responsive lot" src="images/11.png" alt="" style="width:620px; height:170px;">
							   <div class="b-wrapper">
									<div class="b-animate b-from-left b-delay03 ">
										<i class="plus second"></i>
									</div>
							   </div>
						</a>
					</div>
					
					<div class="clearfix"></div>
			</div>
		</div>
	</div>
<!-- pricing -->
<!-- happy -->
	<div class="happy agileinfo wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
		<div class="col-md-6 happy-left">
			<h4>HAPPY CUSTOMERS</h4>
			<p style="text-align: justify; padding-left: 10px; padding-right: 10px;"> Sejak menggunakan PeriJasa, saya tidak perlu pusing dengan kebersihan rumah saya. Pengerjaan sangat rapi, terstruktur, dan profesional. Plus ditambah gratis servis AC hingga 3 kali sebulan. Saya sangat-sangat terbantu dengan adanya PeriJasa.</p>
			<img class="img-responsive" src="images/t2.jpg" alt="">
		</div>
		<div class="col-md-6 happy-right">
			<h4>SUBSCRIBE</h4>
				<form>
					<input type="text" value="Your Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Your Email';}">
					<input type="submit" value="Subscribe">
				</form>
		</div>
		<div class="clearfix"></div>
	</div>
<!-- /happy -->		
<!-- services -->
<div class="container wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
		<div class="contact" id="contact">
			<div class="contact-top">
				<h3>Contact Us</h3>
			</div>
				<form action="#" method="post">	
					<div class="col-md-6 contact-left">
						<input type="text" value="First name" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='First name';}">	
					</div>
					<div class="col-md-6 contact-right">
						<input type="text" value="Last name" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='Last name';}">
					</div>
					<div class="col-md-6 contact-left">
						<input type="text" value="Subject" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='Subject';}">
					</div>
					<div class="col-md-6 contact-right">
						<input type="text" value="Email" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='Email';}">
					</div>	
					<div class="clearfix"></div>
						<textarea cols="77" rows="6" value=" " onfocus="this.value='';" onblur="if (this.value == '') {this.value = 'Message';}">Message</textarea>
						<div class="send">
							<input type="submit" value="Send">
						</div>
				</form>
		</div>
	</div>

<!-- /services -->	
<!-- footer-top -->	
	<div class="footer-top wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
		<div class="container">
			<div class="col-md-3 foot-left">
				<h3>About Us</h3>
				<h2><a href="index.php">Perijasa</a></h2>
				<p style="text-align: justify;">PeriJasa adalah website yang menyediakan paket pelayanan jasa yang bergerak di bidang perawatan rumah, baik dari kebersihan, hingga perawatan alat-alat rumah tangga.</p>
			</div>
			<div class="col-md-3 foot-left">
					<h3>Get In Touch</h3>
					<p>Hubungi Kami</p>
				
						<div class="contact-btm">
							<span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>
							<p>Jalur Sutera Barat Kav.21, </p>
							<p style="padding-left: 22px;">Alam Sutera, Tangerang</p>
						</div>
						<div class="contact-btm">
							<span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>
							<p>+021 123 7890</p>
						<div class="contact-btm">
						</div>
							<span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>
							<p><a href="mailto:example@email.com">custservice@perijasa.tk</a></p>
						</div>
						<div class="clearfix"></div>

			</div>
			<div class="col-md-3 foot-left">
				<h3>Latest Works</h3>
				<li><a href="#"><img src="images/9.jpg" alt="" class="img-responsive"></a></li>
				<li><a href="#"><img src="images/10.jpg" alt="" class="img-responsive"></a></li>
				<li><a href="#"><img src="images/11.png" alt="" class="img-responsive"></a></li>
				<div class="clearfix"></div>
			</div>
			<div class="col-md-3 foot-left">
			<h3>Subscribe</h3>
			<p>Subscribe untuk terus update tentang PeriJasa</p>
			<form action="#" method="post">	
				<input type="text" value="Your Email" name="email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Your Email';}">
				<input type="submit" value="Subscribe">
			</form>
			</div>
				<div class="clearfix"></div>
		</div>
	</div>

<!-- /footer-top -->							
<!--- footer ---->	
<div class="footer wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
	<div class="container">
		<p>© 2016 Concerted. All Rights Reserved | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
	</div>
</div>
<a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 0;"></span> <span id="toTopHover" style="opacity: 0;"> </span></a>
<!--- footer ---->	
</body>
</html>