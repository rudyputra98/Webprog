<?php
	session_start();
	include 'web/connect.php';
?>

<!DOCTYPE HTML>
<html>
<head>
<title>PeriJasa - Penyakit Rumah, Kami Dokternya</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Concerted Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="applijewelleryion/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href='//fonts.googleapis.com/css?family=Viga' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,700,300' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel='stylesheet' type='text/css' />	
<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/move-top.js"></script>
       <script type="text/javascript" src="js/easing.js"></script>
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$(".scroll").click(function(event){		
					event.preventDefault();
					$('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
				});
			});
		</script>
		<script type="text/javascript">
		$(document).ready(function() {
				
		$().UItoTop({ easingType: 'easeOutQuart' });
});
</script>
 <script src="js/jquery.chocolat.js"></script>
		<link rel="stylesheet" href="css/chocolat.css" type="text/css" media="all" />
		<!--light-box-files -->
		<script type="text/javascript">
		$(function() {
			$('#example1 a').Chocolat();
		});
		</script>
		<script type="text/javascript">
		$(function() {
			$('#portfolio a').Chocolat();
		});
		</script>
		<!-- animation-effect -->
<link href="css/animate.min.css" rel="stylesheet"> 
<script src="js/wow.min.js"></script>
<script src="js/my.js"></script>
<link rel="stylesheet" type="text/css" href="css/style.css">
<script>
 new WOW().init();
</script>
<style type="text/css">
	table {
	    font-family: arial, sans-serif;
	    border-collapse: collapse;
	    width: 50%;
	}

	td, th {
		border: 1px solid #dddddd;
		text-align: left;
		padding: 8px;
	}

	tr:nth-child(odd) {
		background-color: #dddddd;
	}	

	.dropbtn {
    background-color: transparent;
    color: white;
    padding: 4px;
    font-size: 17px;
    border: none;
    cursor: pointer;
	}

	.dropdown {
	    position: relative;
	    display: inline-block;
	}

	.dropdown-content {
	    display: none;
	    position: absolute;
	    background-color: #f9f9f9;
	    min-width: 160px;
	    overflow: auto;
	    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
	}

	.dropdown-content a {
	    color: black;
	    padding: 12px 16px;
	    text-decoration: none;
	    display: block;
	}

	.dropdown a:hover {background-color: #f1f1f1}

	.show {display:block;}

</style>
<!-- //animation-effect -->

</head>
<body>
<!-- banner -->
<div class="banner w3l-1" style="background: transparent; margin-top: -500px;">
 <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header wow fadeInLeft animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <h1><a class="navbar-brand" href="home.php"><img src="images/logo3.png" style="width: 140px;height: 40px;"></a></h1>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li>
            <?php 
            	if(strcmp($_SESSION['role'],"member")==0){
            ?>
				<a href="log_ok.php">Home</a>
			<?php
				}else{ 
			?>
				<a href="log_okadmin.php">Home</a>
			<?php	
				}
			?>
            </li>
            <li><a href="log_ok.php">Services</a></li>
			<li><a href="log_ok.php">Pricing</a></li>
			<li><a href="log_ok.php">About</a></li>
			<li><a href="log_ok.php">Projects</a></li>
            <li><a href="order.php" >Order</a></li>
            <li><a href="log_ok.php">Contact</a></li>
            <li>
            	<div class="dropdown" style="margin-top: 9px;">
				<button onclick="myFunction()" class="dropbtn">
            	Hi, 
            	<?php
            		if(isset($_SESSION['name'])){
            			echo $_SESSION['name'];
            		}
            	?></button>
				  <div id="myDropdown" class="dropdown-content">
				    <a href="profile.php">Profile</a>
				    <a href="web/changepassword.php?">Change Password</a>
				  </div>
				</div>
            </li>
            <li><a href="web/DoLogout.php">Log Out</a></li>
          </ul>
        <div class="clearfix"></div>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
 </div>
 	<div style="text-align: center; margin: 20px; padding: 2px;">
 		<table align="center">
			<tr><td colspan="2"><h2 style="text-align: center;">My Profile</h2></td></tr>
 			<?php 
 				$id = $_SESSION["id"];
				$query = "SELECT * FROM account WHERE Userid = '$id'";
			 	$result = mysqli_query($conn,$query);
			 	$row = mysqli_fetch_array($result); 
			?>
			<img style="max-height: 180px;" src="images/<?php printf("%s\n",$row["foto"]) ?>">
 			<tr><td>Nama</td><td><?php printf("%s\n",$row["name"]) ?></td></tr>
 			<tr><td>Email</td><td><?php printf("%s\n",$row["email"]) ?></td></tr>
 			<tr><td>Phone</td><td><?php printf("%s\n",$row["phone"]) ?></td></tr>
 			<tr><td>Address</td><td><?php printf("%s\n",$row["address"]) ?></td></tr>
 		</table>
 		<a href="editprofile.php" class="button but3">Edit Profile</a>
 	</div>
	<div class="footer-top wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
		<div class="container">
			<div class="col-md-3 foot-left">
				<h3>About Us</h3>
				<h2><a href="index.php">Perijasa</a></h2>
				<p style="text-align: justify;">PeriJasa adalah website yang menyediakan paket pelayanan jasa yang bergerak di bidang perawatan rumah, baik dari kebersihan, hingga perawatan alat-alat rumah tangga.</p>
			</div>
			<div class="col-md-3 foot-left">
					<h3>Get In Touch</h3>
					<p>Hubungi Kami</p>
				
						<div class="contact-btm">
							<span class="glyphicon glyphicon-map-marker" aria-hidden="true"></span>
							<p>Jalur Sutera Barat Kav.21, </p>
							<p style="padding-left: 22px;">Alam Sutera, Tangerang</p>
						</div>
						<div class="contact-btm">
							<span class="glyphicon glyphicon-earphone" aria-hidden="true"></span>
							<p>+021 123 7890</p>
						<div class="contact-btm">
						</div>
							<span class="glyphicon glyphicon-envelope" aria-hidden="true"></span>
							<p><a href="mailto:example@email.com">custservice@perijasa.tk</a></p>
						</div>
						<div class="clearfix"></div>

			</div>
			<div class="col-md-3 foot-left">
				<h3>Latest Works</h3>
				<li><a href="#"><img src="images/9.jpg" alt="" class="img-responsive"></a></li>
				<li><a href="#"><img src="images/10.jpg" alt="" class="img-responsive"></a></li>
				<li><a href="#"><img src="images/11.png" alt="" class="img-responsive"></a></li>
				<div class="clearfix"></div>
			</div>
			<div class="col-md-3 foot-left">
			<h3>Subscribe</h3>
			<p>Subscribe untuk terus update tentang PeriJasa</p>
			<form action="#" method="post">	
				<input type="text" value="Your Email" name="email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Your Email';}">
				<input type="submit" value="Subscribe">
			</form>
			</div>
				<div class="clearfix"></div>
		</div>
	</div>

<!-- /footer-top -->							
<!--- footer ---->	
<div class="footer wow fadeInDown"  data-wow-duration=".8s" data-wow-delay=".2s">
	<div class="container">
		<p>© 2016 Concerted. All Rights Reserved | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
	</div>
</div>
<a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 0;"></span> <span id="toTopHover" style="opacity: 0;"> </span></a>
<!--- footer ---->	
</body>
</html>