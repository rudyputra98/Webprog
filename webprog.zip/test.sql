-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2017 at 02:59 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `Userid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `password` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `role` varchar(12) NOT NULL DEFAULT 'member',
  `foto` varchar(50) DEFAULT 'blank.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`Userid`, `name`, `email`, `phone`, `password`, `address`, `role`, `foto`) VALUES
(1, 'Rudy Putra', 'rudy_putra11@rocketmail.com', '085378523789', 'rudy', 'Jl. Jalur Sutera Barat Kav.21 ,Alam Sutera', 'admin', 't2.jpg'),
(4, 'Rudy Putra', 'putrarudy1998@gmail.com', '081918938989', 'webprog yuhu', 'Jl. Jalur Sutera Barat Kav.21 ,Alam Sutera', 'member', 'blank.jpg'),
(5, 'Dewi Nursalim', 'dewiilim@yahoo.com', '0839385764', 'apaaja', 'Jl. Jalur Sutera Barat Kav.21 ,Alam Sutera', 'member', 'blank.jpg'),
(6, 'Lobak', 'lobakbulus@gmail.com', '085378523766', 'lobaksayur', 'Jl. Jalur Sutera Barat Kav.21 ,Alam Sutera', 'member', 'blank.jpg'),
(7, 'Sky', 'skyconnectiva@gmail.com', '09282287373', 'apaaja', 'Jl. Jalur Sutera Barat Kav.21 ,Alam Sutera', 'member', 'blank.jpg'),
(8, 'Sarah', 'sarah@rocketmail.com', '0839745533', 'sarahyahu', 'Jl. Jalur Sutera Barat Kav.21 ,Alam Sutera', 'member', 'blank.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `KodePaket` char(5) NOT NULL,
  `NamaPaket` varchar(50) NOT NULL,
  `Rincian` varchar(200) NOT NULL,
  `Harga` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`KodePaket`, `NamaPaket`, `Rincian`, `Harga`) VALUES
('PK001', 'Bersatu (Bersih Satu)', 'House Cleaning on Weekdays\r\n2.5 jam per session,\r\nFREE servis AC 3 kali sebulan', 'Rp 1.000.000,-'),
('PK002', 'Berdua (Bersih Dua)', 'House Cleaning on Weekdays\r\n2.5 jam per session, \r\nLaundry (tangan/mesin + setrika) on Weekdays\r\n,Gardener setiap 3 hari sekali\r\n,FREE servis AC 3 kali sebulan', 'Rp 2.000.000,-'),
('PK003', 'Bertiga (Bersih Tiga)', 'House Cleaning on Weekdays\r\n2.5 jam per session, \r\n Laundry (tangan/mesin + setrika) on Weekdays\r\n, Gardener setiap 3 hari sekali\r\nFREE servis AC 3 kali sebulan, \r\nFREE jasa pest exterminator 1 kali', 'Rp 3.999.999,-'),
('PK004', 'Garda (Garden Indah)', 'Gardener setiap 3 hari sekali\r\n2.5 jam per session,\r\nFREE servis AC 3 kali sebulan', 'Rp 1.200.000,-'),
('PK005', 'Berenam', 'Cuci baju pake tangan', 'Rp 10.000.000,-');

-- --------------------------------------------------------

--
-- Table structure for table `trdetail`
--

CREATE TABLE `trdetail` (
  `Trid` int(11) NOT NULL,
  `KodePaket` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trdetail`
--

INSERT INTO `trdetail` (`Trid`, `KodePaket`) VALUES
(6, 'PK003'),
(12, 'PK003'),
(13, 'PK003');

-- --------------------------------------------------------

--
-- Table structure for table `trheader`
--

CREATE TABLE `trheader` (
  `Trid` int(11) NOT NULL,
  `Userid` int(11) NOT NULL,
  `Trdate` date NOT NULL,
  `Trtime` time NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trheader`
--

INSERT INTO `trheader` (`Trid`, `Userid`, `Trdate`, `Trtime`, `Status`) VALUES
(6, 1, '2017-01-15', '14:47:00', 'Pending'),
(12, 6, '2017-01-16', '17:48:30', 'Approved'),
(13, 5, '2017-01-16', '17:50:33', 'Pending');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`Userid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`KodePaket`);

--
-- Indexes for table `trdetail`
--
ALTER TABLE `trdetail`
  ADD PRIMARY KEY (`Trid`),
  ADD KEY `Trid` (`Trid`),
  ADD KEY `KodePaket` (`KodePaket`);

--
-- Indexes for table `trheader`
--
ALTER TABLE `trheader`
  ADD PRIMARY KEY (`Trid`),
  ADD KEY `Userid` (`Userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `Userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `trheader`
--
ALTER TABLE `trheader`
  MODIFY `Trid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `trdetail`
--
ALTER TABLE `trdetail`
  ADD CONSTRAINT `trdetail_ibfk_1` FOREIGN KEY (`Trid`) REFERENCES `trheader` (`Trid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `trdetail_ibfk_2` FOREIGN KEY (`KodePaket`) REFERENCES `product` (`KodePaket`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `trheader`
--
ALTER TABLE `trheader`
  ADD CONSTRAINT `trheader_ibfk_1` FOREIGN KEY (`Userid`) REFERENCES `account` (`Userid`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
